#include "stm32f4xx.h"
extern uint32_t SystemCoreClock;
uint32_t systemClock;

#define Timernumber TIM11 // Replace with your timer number
#define Duration 1000 // Replace with your desired duration

void TIM_Config(void);




void RCC_Config() {
    RCC->CR &= ~(1<<0);
    RCC->CR &= 1 << 16;
    while (!(RCC->CR & (1 << 17)));
    RCC->CR &= 1 << 19;
    RCC->PLLCFGR = 0x00000000;
    RCC->PLLCFGR |= (1 << 22);
    RCC->PLLCFGR |= (4 << 0);
    RCC->PLLCFGR |= (168 << 6);
    RCC->CR |= (1 << 24);
    while (!(RCC->CR & (1 << 25)));
    RCC->CFGR &= ~(1 << 0);
    while (!(RCC->CFGR & (1 << 1)));
}

   void GPIO_Config(void)
   {
	   RCC->AHB1ENR |= 1<<3; // GPIOD Clock enable



	       GPIOD->MODER |= 1 << 24;   // GPIOD 11.P�N output
	       GPIOD->MODER &= ~(1 << 25);
	       GPIOD->MODER |= 1 << 26;
	       GPIOD->MODER &= ~(1 << 27);
	       GPIOD->MODER |= 1 << 28;
	       GPIOD->MODER &= ~(1 << 29);
	       GPIOD->MODER |= 1 << 30;
	       GPIOD->MODER &= ~(1 << 31);

	       GPIOD->OSPEEDR |= 0xFF000000;
	   }


int main(void)
{
	RCC_Config();
	SystemCoreClockUpdate();

	GPIO_Config();

 	while (1)
 	{
 		GPIOD->ODR |=1<<12 ;
 		GPIOD->ODR |=1<<13 ;
 		GPIOD->ODR |=1<<14 ;
 		GPIOD->ODR |=1<<15 ;

 		for(int i =0; i< 1680000; i++);
 	    GPIOD->ODR &= ~(1 << 12);
 	   GPIOD->ODR &= ~(1 << 13);
 	 GPIOD->ODR &= ~(1 << 14);
 	  GPIOD->ODR &= ~(1 << 15);

 	 for(int i =0; i< 1680000; i++);


 	}
}

